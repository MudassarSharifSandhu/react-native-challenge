export const activity = [
  {
    title: "johndoe.near",
    dec: "0.34 NEAR",
  },
  {
    title: "mike.near",
    dec: "0.12 NEAR",
  },
  {
    title: "jhon.near",
    dec: "2.34 NEAR",
  },
];
export const activity2 = [
  {
    title: "johndoe.near signed the contract successfully",
    dec: "2 days ago",
  },
  {
    title: "CryptoKing.near requested to sign the contract ",
    dec: "3 days ago",
  },
];
